const ClipOns = {

    attach(id, containerId, renderFn){

        const container = document.getElementById(containerId);

        if(!container) return;

        const el = document.createElement("div");

        el.className = "clipon";

        el.innerHTML = renderFn();

        container.appendChild(el);

        return el;
    }
};

window.ClipOns = ClipOns;