const ModMarket = {

    mods: [],

    async loadIndex(){

        const res = await fetch(this.repo + "/mods.json");
        this.mods = await res.json();

        this.render();
    },

    async loadMod(file){

        const res = await fetch(this.repo + "/mods/" + file);
        const code = await res.text();

        ModAPI.loadAddonScript(code);

        UI.notify("Mod installed: " + file);
    },

    render(){

        const container = document.getElementById("modMenu");

        if(!container) return;

        container.innerHTML = "";

        for(const mod of this.mods){

            const btn = document.createElement("button");

            btn.innerText = mod.name;

            btn.onclick = () => this.loadMod(mod.file);

            container.appendChild(btn);
        }
    }
};