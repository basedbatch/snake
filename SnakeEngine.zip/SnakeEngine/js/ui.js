 const UI = {

    screens: {},

    init(){

        this.screens = {
            mainMenu: document.getElementById("mainMenu"),
            game: document.getElementById("gameScreen"),
            settings: document.getElementById("settingsScreen"),
            campaign: document.getElementById("campaignScreen"),
            editor: document.getElementById("editorScreen"),
            mods: document.getElementById("modsScreen"),
            modMaker: document.getElementById("modMakerScreen"),
            achievements: document.getElementById("achievementScreen"),
            stats: document.getElementById("statsScreen")
        };

        this.show("mainMenu");
    },

    show(name){

        for(let key in this.screens){

            if(this.screens[key]){
                this.screens[key].classList.add("hidden");
            }
        }

        if(this.screens[name]){
            this.screens[name].classList.remove("hidden");
        }
    },

    openGame(){
        this.show("game");
        Game?.reset?.();
    },

    openCampaign(){
        this.show("campaign");
    },

    openEditor(){
        this.show("editor");
        Editor?.init?.();
    },

    openMods(){
        this.show("mods");
        Mods?.refresh?.();
    },

    openModMaker(){
        this.show("modMaker");
        ModMaker?.init?.();
    },

    openSettings(){
        this.show("settings");
    },

    openAchievements(){
        this.show("achievements");
        Achievements?.refresh?.();
    },

    openStats(){
        this.show("stats");
        Saves?.updateStatsUI?.();
    },

    backToMenu(){
        this.show("mainMenu");
    },

    notify(message, time = 2000){

        const div = document.createElement("div");

        div.className = "notification";
        div.innerText = message;

        document.body.appendChild(div);

        setTimeout(() => {
            div.remove();
        }, time);
    },

    toggleFullscreen(){

        if(!document.fullscreenElement){
            document.documentElement.requestFullscreen();
        } else {
            document.exitFullscreen();
        }
    }
};

window.addEventListener("load", () => {
    UI.init();
});
function loadMods(){

    const mods = [
        "assets/mods/corruption_mode.js"
    ];

    for(const path of mods){

        const script = document.createElement("script");

        script.src = path;

        script.onload = () => {
            UI.notify("Loaded mod: " + path);
        };

        document.body.appendChild(script);
    }
}

window.addEventListener("load", loadMods);