const ModAPI = {

    mods: [],

    hooks: {
        start: [],
        update: [],
        frame: [],
        food: [],
        gameOver: []
    },

    registerMod(mod){

        this.mods.push(mod);

        if(mod.hooks){

            for(const event in mod.hooks){

                if(!this.hooks[event]) this.hooks[event] = [];

                this.hooks[event].push(mod.hooks[event].bind(mod));
            }
        }

        if(mod.init){
            mod.init(this);
        }
    },

    emit(event, Game){

        const list = this.hooks[event];

        if(!list) return;

        for(const fn of list){
            try { fn(Game); }
            catch(e){ console.error("Mod error:", e); }
        }
    }
};