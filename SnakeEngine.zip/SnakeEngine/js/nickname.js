const Nickname = {

    name: "Player",

    blockedPatterns: [
        /sonic\s*\.?\s*exe/i,
        /sonicexe/i,
        /\.exe/i,
        /sex/i,
        /nsfw/i,
        /porn/i,
        /xxx/i,
        /horny/i,
        /nsf/i,
        /gore/i,
        /kill\s*yourself/i,

        // brainrot / troll patterns
        /skibidi/i,
        /sigma/i,
        /gyatt/i,
        /rizz/i,
        /skrunkly/i,
        /brr/i,
        /uwu/i,
    ],

    setName(input){

        const cleaned = input.trim();

        if(!this.isValid(cleaned)){

            UI.notify("❌ No buddy, use a different name/nickname");

            return false;
        }

        this.name = cleaned;

        localStorage.setItem("snake_nickname", cleaned);

        UI.notify("✔ Welcome, " + cleaned);

        return true;
    },

    isValid(name){

        if(!name || name.length < 2) return false;

        for(const pattern of this.blockedPatterns){

            if(pattern.test(name)){
                return false;
            }
        }

        return true;
    },

    load(){

        const saved = localStorage.getItem("snake_nickname");

        if(saved && this.isValid(saved)){
            this.name = saved;
        }
    }
};

window.addEventListener("load", () => Nickname.load());