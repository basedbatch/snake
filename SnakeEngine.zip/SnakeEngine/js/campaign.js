const Campaign = {

    data: {

        currentWorld: null,
        currentLevel: null,

        worlds: {

            grasslands: {
                name: "Grasslands",
                levels: ["g1","g2","g3"],
                unlocked: true
            },

            desert: {
                name: "Desert",
                levels: ["d1","d2","d3"],
                unlocked: false
            },

            ice: {
                name: "Ice World",
                levels: ["i1","i2","i3"],
                unlocked: false
            },

            volcano: {
                name: "Volcano",
                levels: ["v1","v2","v3"],
                unlocked: false
            },

            lab: {
                name: "Laboratory",
                levels: ["l1","l2","l3"],
                unlocked: false
            },

            cyber: {
                name: "Cyber World",
                levels: ["c1","c2","c3"],
                unlocked: false
            },

            void: {
                name: "Void",
                levels: ["x1","x2","x3"],
                unlocked: false
            },

            corruption: {
                name: "Corruption Realm",
                levels: ["r1","r2","r3"],
                unlocked: false
            }
        }
    },

    init(){

        const saved =
            localStorage.getItem("snake_campaign");

        if(saved){
            this.data = JSON.parse(saved);
        }

        this.refreshUI();
    },

    save(){

        localStorage.setItem(
            "snake_campaign",
            JSON.stringify(this.data)
        );
    },

    startWorld(worldId){

        const world = this.data.worlds[worldId];

        if(!world || !world.unlocked){
            UI.notify("World locked!");
            return;
        }

        this.data.currentWorld = worldId;
        this.data.currentLevel = world.levels[0];

        this.save();

        UI.notify("Entering " + world.name);

        UI.openGame();

        Game.reset();
    },

    nextLevel(){

        const world =
            this.data.worlds[this.data.currentWorld];

        if(!world) return;

        const index =
            world.levels.indexOf(this.data.currentLevel);

        if(index < world.levels.length - 1){

            this.data.currentLevel =
                world.levels[index + 1];

            UI.notify("Next Level!");

        } else {

            this.completeWorld();
        }

        this.save();
    },

    completeWorld(){

        UI.notify("World Completed!");

        const keys = Object.keys(this.data.worlds);

        const currentIndex =
            keys.indexOf(this.data.currentWorld);

        const nextWorld =
            keys[currentIndex + 1];

        if(nextWorld){

            this.data.worlds[nextWorld].unlocked = true;

            UI.notify(
                this.data.worlds[nextWorld].name + " unlocked!"
            );
        }

        this.save();
        this.refreshUI();
    },

    failLevel(){

        UI.notify("Level Failed!");

        Game.reset();
    },

    refreshUI(){

        const container =
            document.getElementById("campaignList");

        if(!container) return;

        container.innerHTML = "";

        for(let id in this.data.worlds){

            const w = this.data.worlds[id];

            const btn = document.createElement("button");

            btn.innerText =
                w.name +
                (w.unlocked ? "" : " 🔒");

            btn.onclick = () => this.startWorld(id);

            container.appendChild(btn);
        }
    },

    reset(){

        localStorage.removeItem("snake_campaign");

        this.data = {

            currentWorld: null,
            currentLevel: null,

            worlds: {

                grasslands: {
                    name: "Grasslands",
                    levels: ["g1","g2","g3"],
                    unlocked: true
                },

                desert: {
                    name: "Desert",
                    levels: ["d1","d2","d3"],
                    unlocked: false
                },

                ice: {
                    name: "Ice World",
                    levels: ["i1","i2","i3"],
                    unlocked: false
                },

                volcano: {
                    name: "Volcano",
                    levels: ["v1","v2","v3"],
                    unlocked: false
                },

                lab: {
                    name: "Laboratory",
                    levels: ["l1","l2","l3"],
                    unlocked: false
                },

                cyber: {
                    name: "Cyber World",
                    levels: ["c1","c2","c3"],
                    unlocked: false
                },

                void: {
                    name: "Void",
                    levels: ["x1","x2","x3"],
                    unlocked: false
                },

                corruption: {
                    name: "Corruption Realm",
                    levels: ["r1","r2","r3"],
                    unlocked: false
                }
            }
        };

        this.save();
        this.refreshUI();

        UI.notify("Campaign reset!");
    }
};

window.addEventListener("load", () => {
    Campaign.init();
});