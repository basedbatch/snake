const Achievements = {

    data: {

        unlocked: {},

        list: {

            first_food: {
                name: "First Bite",
                desc: "Eat your first food",
                check: (Game, Saves) => Game.score >= 1
            },

            ten_food: {
                name: "Snack Time",
                desc: "Eat 10 food",
                check: (Game, Saves) => Game.score >= 10
            },

            length_20: {
                name: "Growing",
                desc: "Reach length 20",
                check: (Game, Saves) => Game.snake.length >= 20
            },

            games_5: {
                name: "Addicted",
                desc: "Play 5 games",
                check: (Game, Saves) =>
                    Saves.getStat("gamesPlayed") >= 5
            },

            food_100: {
                name: "Feast",
                desc: "Eat 100 food total",
                check: (Game, Saves) =>
                    Saves.getStat("foodEaten") >= 100
            },

            boss_killer: {
                name: "Boss Slayer",
                desc: "Defeat your first boss",
                check: (Game, Saves) =>
                    Saves.getStat("bossesDefeated") >= 1
            }
        }
    },

    init(){

        const saved =
            localStorage.getItem("snake_achievements");

        if(saved){
            this.data.unlocked = JSON.parse(saved);
        }

        this.refresh();
    },

    save(){

        localStorage.setItem(
            "snake_achievements",
            JSON.stringify(this.data.unlocked)
        );
    },

    check(){

        for(let id in this.data.list){

            if(this.data.unlocked[id]) continue;

            const a = this.data.list[id];

            try{

                if(a.check(Game, Saves)){

                    this.unlock(id);

                }

            } catch(e){
                console.error(e);
            }
        }
    },

    unlock(id){

        this.data.unlocked[id] = true;

        this.save();

        this.popup(this.data.list[id]);

        UI.notify("Achievement: " + this.data.list[id].name);
    },

    popup(ach){

        const div = document.createElement("div");

        div.className = "notification";

        div.innerHTML = `
            <b>Achievement Unlocked</b><br>
            ${ach.name}<br>
            <small>${ach.desc}</small>
        `;

        document.body.appendChild(div);

        setTimeout(() => {
            div.remove();
        }, 3000);
    },

    refresh(){

        const list =
            document.getElementById("achievementList");

        if(!list) return;

        list.innerHTML = "";

        for(let id in this.data.list){

            const a = this.data.list[id];

            const li = document.createElement("li");

            const unlocked =
                this.data.unlocked[id] ? "✅" : "🔒";

            li.innerText =
                `${unlocked} ${a.name} - ${a.desc}`;

            list.appendChild(li);
        }
    },

    reset(){

        localStorage.removeItem("snake_achievements");

        this.data.unlocked = {};

        this.refresh();

        UI.notify("Achievements reset!");
    }
};

/* Hook into game loop */

window.addEventListener("load", () => {

    setInterval(() => {

        if(Game && Saves){
            Achievements.check();
        }

    }, 1000);

    Achievements.init();
});