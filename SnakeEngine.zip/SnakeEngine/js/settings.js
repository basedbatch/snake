const Settings = {

    data: {

        volume: 100,
        showFPS: false,
        showGrid: true,
        fullscreen: false,
        particles: true,
        autosave: true,
        snakeSpeed: 100
    },

    init(){

        const saved = localStorage.getItem("snake_settings");

        if(saved){
            this.data = JSON.parse(saved);
        }

        this.applyToUI();
        this.apply();
    },

    applyToUI(){

        const d = this.data;

        const volume = document.getElementById("volume");
        const fps = document.getElementById("showFPS");
        const grid = document.getElementById("showGrid");
        const fullscreen = document.getElementById("fullscreen");
        const particles = document.getElementById("particles");
        const autosave = document.getElementById("autosave");

        if(volume) volume.value = d.volume;
        if(fps) fps.checked = d.showFPS;
        if(grid) grid.checked = d.showGrid;
        if(fullscreen) fullscreen.checked = d.fullscreen;
        if(particles) particles.checked = d.particles;
        if(autosave) autosave.checked = d.autosave;
    },

    readFromUI(){

        this.data.volume =
            parseInt(document.getElementById("volume").value);

        this.data.showFPS =
            document.getElementById("showFPS").checked;

        this.data.showGrid =
            document.getElementById("showGrid").checked;

        this.data.fullscreen =
            document.getElementById("fullscreen").checked;

        this.data.particles =
            document.getElementById("particles").checked;

        this.data.autosave =
            document.getElementById("autosave").checked;
    },

    save(){

        this.readFromUI();

        localStorage.setItem(
            "snake_settings",
            JSON.stringify(this.data)
        );

        this.apply();

        UI.notify("Settings saved!");
    },

    apply(){

        // Apply speed to game
        if(Game){
            Game.speed = this.data.snakeSpeed;
        }

        // Apply grid toggle
        if(Game){
            Game.showGrid = this.data.showGrid;
        }

        // fullscreen (optional)
        if(this.data.fullscreen && !document.fullscreenElement){
            document.documentElement.requestFullscreen().catch(()=>{});
        }

        // notify system usage
        UI?.notify?.("Settings applied");
    },

    reset(){

        localStorage.removeItem("snake_settings");

        this.data = {

            volume: 100,
            showFPS: false,
            showGrid: true,
            fullscreen: false,
            particles: true,
            autosave: true,
            snakeSpeed: 100
        };

        this.applyToUI();
        this.apply();

        UI.notify("Settings reset!");
    }
};

window.addEventListener("load", () => {

    Settings.init();
});