const Movement = {

    dir: {x: 1, y: 0},

    buffer: {x: 1, y: 0},

    init(){

        Keybinds.on("up", () => this.queue(0, -1));
        Keybinds.on("down", () => this.queue(0, 1));
        Keybinds.on("left", () => this.queue(-1, 0));
        Keybinds.on("right", () => this.queue(1, 0));
    },

    queue(x, y){

        // prevent instant reverse
        if(this.dir.x === -x && this.dir.y === -y) return;

        this.buffer = {x, y};
    },

    apply(){

        this.dir = this.buffer;
    }
};

window.Movement = Movement;

window.addEventListener("load", () => Movement.init());