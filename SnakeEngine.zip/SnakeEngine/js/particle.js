const Particles = {

    list: [],

    spawn(x, y, color = "white", count = 10){

        for(let i=0;i<count;i++){

            this.list.push({
                x, y,
                vx:(Math.random()-0.5)*4,
                vy:(Math.random()-0.5)*4,
                life: 60,
                color
            });
        }
    },

    update(ctx){

        for(let i=this.list.length-1;i>=0;i--){

            const p = this.list[i];

            p.x += p.vx;
            p.y += p.vy;
            p.life--;

            ctx.fillStyle = p.color;
            ctx.fillRect(p.x, p.y, 3, 3);

            if(p.life <= 0){
                this.list.splice(i,1);
            }
        }
    }
};