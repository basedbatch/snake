const Game = {

    canvas: null,
    ctx: null,

    grid: 20,
    size: 30,

    snake: [],
    dir: {x:1,y:0},

    food: {x:10,y:10},

    walls: [],

    score: 0,
    running: false,
    interval: null,

    speed: 100,

    init(){

        this.canvas = document.getElementById("gameCanvas");
        this.ctx = this.canvas.getContext("2d");

        this.reset();

        document.addEventListener("keydown", (e) => {

            switch(e.key){

                case "ArrowUp":
                    if(this.dir.y === 0)
                        this.dir = {x:0,y:-1};
                    break;

                case "ArrowDown":
                    if(this.dir.y === 0)
                        this.dir = {x:0,y:1};
                    break;

                case "ArrowLeft":
                    if(this.dir.x === 0)
                        this.dir = {x:-1,y:0};
                    break;

                case "ArrowRight":
                    if(this.dir.x === 0)
                        this.dir = {x:1,y:0};
                    break;
            }
        });
    },

    reset(){

        this.snake = [
            {x:15,y:15},
            {x:14,y:15},
            {x:13,y:15}
        ];

        this.dir = {x:1,y:0};

        this.food = this.randomPos();

        this.score = 0;

        this.walls = [];

        this.running = false;

        if(this.interval){
            clearInterval(this.interval);
        }

        this.draw();
    },

    start(){

        if(this.running) return;

        this.running = true;

        this.interval = setInterval(() => {

            this.update();
            this.draw();

            ModAPI?.runFrame?.();

        }, this.speed);
    },

    pause(){

        this.running = false;

        clearInterval(this.interval);
    },

    update(){
		Movement.apply();
		Game.dir = Movement.dir;
		Sound.eat();
		Particles.spawn(head.x*20, head.y*20, "red", 6);
        const head = {
            x: this.snake[0].x + this.dir.x,
            y: this.snake[0].y + this.dir.y
        };

        // wall collision
        for(let w of this.walls){
            if(w.x === head.x && w.y === head.y){
                return this.gameOver();
            }
        }

        // border collision
        if(
            head.x < 0 ||
            head.y < 0 ||
            head.x >= this.size ||
            head.y >= this.size
        ){
            return this.gameOver();
        }

        this.snake.unshift(head);

        // food
		Sound.eat();
		Particles.spawn(this.food.x*20, this.food.y*20, "yellow", 12);
        if(head.x === this.food.x && head.y === this.food.y){
			
            this.score++;

            this.food = this.randomPos();

           ModAPI.emit("food", this);

        } else {
            this.snake.pop();
        }

        ModAPI.emit("update", this);
		ModAPI.emit("frame", this);
    },

    draw(){
		if(Game.bgImage){
			
    const img = new Image();

    img.src = Game.bgImage;

    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			}
        const c = this.ctx;

        c.clearRect(0,0,800,600);
			
        // grid (optional light debug)
        if(Settings?.data?.grid){

            c.strokeStyle = "#222";

            for(let i=0;i<40;i++){
                c.beginPath();
                c.moveTo(i*this.grid,0);
                c.lineTo(i*this.grid,600);
                c.stroke();

                c.beginPath();
                c.moveTo(0,i*this.grid);
                c.lineTo(800,i*this.grid);
                c.stroke();
            }
        }

        // food
        c.fillStyle = "red";
        c.fillRect(
            this.food.x * this.grid,
            this.food.y * this.grid,
            this.grid,
            this.grid
        );

        // walls
        c.fillStyle = "gray";

        for(let w of this.walls){

            c.fillRect(
                w.x * this.grid,
                w.y * this.grid,
                this.grid,
                this.grid
            );
        }

        // snake
        c.fillStyle = window.snakeColor || "lime";

        for(let i=0;i<this.snake.length;i++){

            const s = this.snake[i];

            c.fillRect(
                s.x * this.grid,
                s.y * this.grid,
                this.grid,
                this.grid
            );
        }

        // score
        c.fillStyle = "white";
        c.font = "16px Arial";
        c.fillText("Score: " + this.score, 10, 20);
    },

    randomPos(){

        return {
            x: Math.floor(Math.random()*this.size),
            y: Math.floor(Math.random()*this.size)
        };
    },

    gameOver(){

        this.pause();

        UI.notify("Game Over! Score: " + this.score, 3000);

        Saves?.addStat?.("gamesPlayed", 1);

        Saves?.addStat?.("foodEaten", this.score);

        setTimeout(() => {
            this.reset();
        }, 1000);
    }
};

window.addEventListener("load", () => {
    Game.init();
});