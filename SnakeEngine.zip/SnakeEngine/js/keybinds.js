const Keybinds = {

    map: {
        up: "ArrowUp",
        down: "ArrowDown",
        left: "ArrowLeft",
        right: "ArrowRight",
        pause: "Space"
    },

    listeners: {},

    set(action, key){
        this.map[action] = key;
    },

    on(action, fn){

        if(!this.listeners[action]){
            this.listeners[action] = [];
        }

        this.listeners[action].push(fn);
    },

    trigger(action, data){

        const list = this.listeners[action];

        if(!list) return;

        for(const fn of list){
            fn(data);
        }
    },

    init(){

        document.addEventListener("keydown", (e) => {

            for(const action in this.map){

                if(e.key === this.map[action]){
                    this.trigger(action, e);
                }
            }
        });
    }
};

window.Keybinds = Keybinds;

window.addEventListener("load", () => Keybinds.init());