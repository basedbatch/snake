ModAPI.registerMod({

    name: "Background System",

    state: {
        images: [],
        index: 0
    },

    init(ModAPI){

        fetch("assets/backgrounds/backgrounds.json")
            .then(r => r.json())
            .then(data => this.state.images = data);
    },

    hooks: {

        frame(Game){

            if(!this.state.images.length) return;

            Game.bgImage =
                this.state.images[this.state.index];
        },

        update(Game){

            if(Math.random() < 0.01){
                this.state.index++;

                if(this.state.index >= this.state.images.length){
                    this.state.index = 0;
                }
            }
        }
    }
});