const Saves = {

    data: {

        stats: {
            gamesPlayed: 0,
            foodEaten: 0,
            highestLength: 0,
            bossesDefeated: 0
        },

        unlockedLevels: [],
        unlockedMods: []
    },

    init(){

        const saved = localStorage.getItem("snake_saves");

        if(saved){
            this.data = JSON.parse(saved);
        }

        this.updateStatsUI();
    },

    save(){

        localStorage.setItem(
            "snake_saves",
            JSON.stringify(this.data)
        );
    },

    addStat(key, value){

        if(this.data.stats[key] === undefined)
            this.data.stats[key] = 0;

        this.data.stats[key] += value;

        this.save();
        this.updateStatsUI();
    },

    setStat(key, value){

        this.data.stats[key] = value;

        this.save();
        this.updateStatsUI();
    },

    getStat(key){

        return this.data.stats[key] || 0;
    },

    unlockLevel(levelId){

        if(!this.data.unlockedLevels.includes(levelId)){
            this.data.unlockedLevels.push(levelId);
        }

        this.save();
    },

    unlockMod(modName){

        if(!this.data.unlockedMods.includes(modName)){
            this.data.unlockedMods.push(modName);
        }

        this.save();
    },

    updateStatsUI(){

        const gs = document.getElementById("gamesPlayed");
        const fe = document.getElementById("foodEaten");
        const hl = document.getElementById("highestLength");
        const bd = document.getElementById("bossesDefeated");

        if(gs) gs.innerText =
            "Games Played: " + this.getStat("gamesPlayed");

        if(fe) fe.innerText =
            "Food Eaten: " + this.getStat("foodEaten");

        if(hl) hl.innerText =
            "Highest Length: " + this.getStat("highestLength");

        if(bd) bd.innerText =
            "Bosses Defeated: " + this.getStat("bossesDefeated");
    },

    reset(){

        this.data = {

            stats: {
                gamesPlayed: 0,
                foodEaten: 0,
                highestLength: 0,
                bossesDefeated: 0
            },

            unlockedLevels: [],
            unlockedMods: []
        };

        this.save();
        this.updateStatsUI();

        UI.notify("Saves reset!");
    }
};

window.addEventListener("load", () => {
    Saves.init();
});