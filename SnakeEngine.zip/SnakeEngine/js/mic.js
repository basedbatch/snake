const Mic = {

    stream: null,
    analyser: null,
    data: null,
    enabled: false,

    async init(){

        try{

            this.stream = await navigator.mediaDevices.getUserMedia({
                audio:true
            });

            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const source = ctx.createMediaStreamSource(this.stream);

            this.analyser = ctx.createAnalyser();
            source.connect(this.analyser);

            this.data = new Uint8Array(this.analyser.frequencyBinCount);

            this.enabled = true;

            UI.notify("Mic enabled");

        } catch(e){
            console.warn("Mic blocked");
        }
    },

    getVolume(){

        if(!this.enabled) return 0;

        this.analyser.getByteFrequencyData(this.data);

        let sum = 0;

        for(let i=0;i<this.data.length;i++){
            sum += this.data[i];
        }

        return sum / this.data.length;
    }
};

window.addEventListener("load", () => Mic.init());