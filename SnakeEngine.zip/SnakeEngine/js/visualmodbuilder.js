const VisualModBuilder = {

    nodes: [],

    createNode(type, x=100, y=100){

        const node = {
            id: Date.now()+Math.random(),
            type,
            x, y,
            data: {}
        };

        this.nodes.push(node);

        this.render(node);

        return node;
    },

    render(node){

        const div = document.createElement("div");

        div.className = "vnode";
        div.style.left = node.x + "px";
        div.style.top = node.y + "px";

        div.innerHTML = `
            <b>${node.type}</b>
            <br>
            <small>drag me</small>
        `;

        div.onmousedown = (e) => {

            const offsetX = e.offsetX;
            const offsetY = e.offsetY;

            document.onmousemove = (ev) => {
                node.x = ev.clientX - offsetX;
                node.y = ev.clientY - offsetY;

                div.style.left = node.x + "px";
                div.style.top = node.y + "px";
            };

            document.onmouseup = () => {
                document.onmousemove = null;
            };
        };

        document.body.appendChild(div);
    },

    compile(){

        let code = `ModAPI.registerMod({\n`;

        for(let n of this.nodes){

            if(n.type === "foodBoost"){
                code += `
onFood(Game){
    Game.score += 2;
},
`;
            }

            if(n.type === "speedBoost"){
                code += `
onUpdate(Game){
    Game.speed = 50;
},
`;
            }

            if(n.type === "particles"){
                code += `
onFrame(Game){
    Particles.spawn(Game.snake[0].x*20, Game.snake[0].y*20, "cyan", 5);
},
`;
            }
        }

        code += "\n});";

        return code;
    }
};