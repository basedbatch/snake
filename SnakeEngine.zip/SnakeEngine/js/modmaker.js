const ModMaker = {

    editor: null,

    init(){

        this.editor = document.getElementById("modEditor");

        this.setTemplate("custom");
    },

    newTemplate(){

        const type = document.getElementById("templateType").value;

        this.setTemplate(type);
    },

    setTemplate(type){

        const name = document.getElementById("modName").value || "MyMod";

        let code = "";

        switch(type){

            case "food":
                code = `
ModAPI.registerMod({

    onFood(Game){
        Game.score += 1;
        UI.notify("Food mod triggered!");
    }

});
                `;
                break;

            case "enemy":
                code = `
ModAPI.registerMod({

    onUpdate(Game){

        if(Math.random() < 0.01){
            UI.notify("Enemy event triggered!");
        }

    }

});
                `;
                break;

            case "boss":
                code = `
ModAPI.registerMod({

    gameMode: {

        name: "Boss Mode",

        onStart(Game){
            UI.notify("Boss appears!");
        },

        onUpdate(Game){
            if(Game.score > 10){
                UI.notify("Boss is angry!");
            }
        }

    }

});
                `;
                break;

            case "gamemode":
                code = `
ModAPI.registerMod({

    gameMode: {

        name: "Chaos Mode",

        onStart(Game){
            UI.notify("Chaos Mode started!");
        },

        onUpdate(Game){

            if(Math.random() < 0.02){
                Game.dir.x = Math.floor(Math.random()*3)-1;
                Game.dir.y = Math.floor(Math.random()*3)-1;
            }

        }

    }

});
                `;
                break;

            case "achievement":
                code = `
ModAPI.registerMod({

    onFood(Game){

        if(Game.score >= 10){
            UI.notify("Achievement: Food Collector!");
        }

    }

});
                `;
                break;

            case "particle":
                code = `
ModAPI.registerMod({

    onFrame(Game){

        // particle effect placeholder
        if(Math.random() < 0.1){
            UI.notify("Particle burst!");
        }

    }

});
                `;
                break;

            case "portal":
                code = `
ModAPI.registerMod({

    onUpdate(Game){

        if(Game.score % 5 === 0 && Game.score > 0){
            UI.notify("Portal event triggered!");
        }

    }

});
                `;
                break;

            default:
                code = `
ModAPI.registerMod({

    onStart(Game){
        UI.notify("Custom Mod Loaded");
    },

    onUpdate(Game){

    },

    onFood(Game){

    },

    onFrame(Game){

    }

});
                `;
        }

        this.editor.value =
            `// Mod: ${name}\n\n` + code;
    },

    run(){

        const code = this.editor.value;

        ModAPI.loadScript(code);

        UI.notify("Mod executed!");
    },

    export(){

        const code = this.editor.value;

        const name =
            document.getElementById("modName").value
            || "mod";

        const blob = new Blob([code], {type:"text/javascript"});

        const a = document.createElement("a");

        a.href = URL.createObjectURL(blob);

        a.download = name + ".js";

        a.click();

        UI.notify("Mod exported!");
    },

    clear(){

        this.editor.value = "";

        UI.notify("Cleared editor");
    }
};

window.addEventListener("load", () => {
    ModMaker.init();
});