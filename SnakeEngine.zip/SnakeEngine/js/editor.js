const Editor = {

    canvas: null,
    ctx: null,

    grid: 20,
    size: 30,

    tool: "wall",

    walls: [],
    foods: [],
    spawns: [],
    portals: [],
    enemies: [],
    bosses: [],

    init(){

        this.canvas = document.getElementById("editorCanvas");
        this.ctx = this.canvas.getContext("2d");

        this.bindTools();
        this.bindCanvas();

        this.draw();
    },

    bindTools(){

        document.getElementById("wallTool").onclick = () => this.tool = "wall";
        document.getElementById("foodTool").onclick = () => this.tool = "food";
        document.getElementById("spawnTool").onclick = () => this.tool = "spawn";
        document.getElementById("portalTool").onclick = () => this.tool = "portal";
        document.getElementById("enemyTool").onclick = () => this.tool = "enemy";
        document.getElementById("bossTool").onclick = () => this.tool = "boss";
        document.getElementById("eraseTool").onclick = () => this.tool = "erase";
    },

    bindCanvas(){

        this.canvas.addEventListener("click", (e) => {

            const rect = this.canvas.getBoundingClientRect();

            const x = Math.floor((e.clientX - rect.left) / this.grid);
            const y = Math.floor((e.clientY - rect.top) / this.grid);

            this.place(x, y);
            this.draw();
        });
    },

    place(x, y){

        if(this.tool === "wall"){
            this.walls.push({x,y});
        }

        else if(this.tool === "food"){
            this.foods.push({x,y});
        }

        else if(this.tool === "spawn"){
            this.spawns = [{x,y}];
        }

        else if(this.tool === "portal"){
            this.portals.push({x,y});
        }

        else if(this.tool === "enemy"){
            this.enemies.push({x,y});
        }

        else if(this.tool === "boss"){
            this.bosses.push({x,y});
        }

        else if(this.tool === "erase"){

            this.erase(x,y);
        }
    },

    erase(x,y){

        const remove = (arr) => {
            for(let i=0;i<arr.length;i++){
                if(arr[i].x === x && arr[i].y === y){
                    arr.splice(i,1);
                    return;
                }
            }
        };

        remove(this.walls);
        remove(this.foods);
        remove(this.portals);
        remove(this.enemies);
        remove(this.bosses);
    },

    exportLevel(){

        const data = {
            walls: this.walls,
            foods: this.foods,
            spawns: this.spawns,
            portals: this.portals,
            enemies: this.enemies,
            bosses: this.bosses
        };

        const blob = new Blob(
            [JSON.stringify(data, null, 2)],
            {type:"application/json"}
        );

        const a = document.createElement("a");

        a.href = URL.createObjectURL(blob);
        a.download = "level.json";

        a.click();

        UI.notify("Level exported!");
    },

    importLevel(){

        const input = document.createElement("input");
        input.type = "file";
        input.accept = ".json";

        input.onchange = (e) => {

            const file = e.target.files[0];
            const reader = new FileReader();

            reader.onload = (ev) => {

                const data = JSON.parse(ev.target.result);

                this.walls = data.walls || [];
                this.foods = data.foods || [];
                this.spawns = data.spawns || [];
                this.portals = data.portals || [];
                this.enemies = data.enemies || [];
                this.bosses = data.bosses || [];

                this.draw();

                UI.notify("Level imported!");
            };

            reader.readAsText(file);
        };

        input.click();
    },

    testLevel(){

        Game.walls = this.walls;

        Game.reset();

        UI.openGame();

        UI.notify("Testing level...");
    },

    draw(){

        const c = this.ctx;

        c.clearRect(0,0,800,600);

        // walls
        c.fillStyle = "gray";
        this.walls.forEach(w => {
            c.fillRect(w.x*this.grid, w.y*this.grid, this.grid, this.grid);
        });

        // food
        c.fillStyle = "red";
        this.foods.forEach(f => {
            c.fillRect(f.x*this.grid, f.y*this.grid, this.grid, this.grid);
        });

        // spawn
        c.fillStyle = "lime";
        this.spawns.forEach(s => {
            c.fillRect(s.x*this.grid, s.y*this.grid, this.grid, this.grid);
        });

        // portals
        c.fillStyle = "cyan";
        this.portals.forEach(p => {
            c.fillRect(p.x*this.grid, p.y*this.grid, this.grid, this.grid);
        });

        // enemies
        c.fillStyle = "orange";
        this.enemies.forEach(e => {
            c.fillRect(e.x*this.grid, e.y*this.grid, this.grid, this.grid);
        });

        // bosses
        c.fillStyle = "purple";
        this.bosses.forEach(b => {
            c.fillRect(b.x*this.grid, b.y*this.grid, this.grid, this.grid);
        });
    }
};

window.addEventListener("load", () => {
    Editor.init();
});