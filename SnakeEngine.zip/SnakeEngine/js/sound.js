const Sound = {

    ctx: null,
    enabled: true,
    volume: 0.5,

    init(){
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    },

    setVolume(v){
        this.volume = v / 100;
    },

    play(freq = 440, time = 0.1, type = "sine"){

        if(!this.enabled || !this.ctx) return;

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = type;
        osc.frequency.value = freq;

        gain.gain.value = this.volume;

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start();
        osc.stop(this.ctx.currentTime + time);
    },

    eat(){
        this.play(600, 0.08, "square");
    },

    hit(){
        this.play(120, 0.2, "sawtooth");
    },

    levelUp(){
        this.play(800, 0.15, "sine");
        setTimeout(() => this.play(1000, 0.15), 120);
    }
};

window.addEventListener("load", () => Sound.init());