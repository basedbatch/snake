const Cheats = {

    teleport(){
        if(!window.CHEATS_ENABLED) return;

        Game.snake[0].x = Math.floor(Math.random()*Game.size);
        Game.snake[0].y = Math.floor(Math.random()*Game.size);
    },

    grow(){
        if(!window.CHEATS_ENABLED) return;

        Game.snake.push({...Game.snake.at(-1)});
    }
};